# pyanimeplanet
A python module to extract information from anime-planet website (no login required)
